<?php 
include '../config.php';

// Ensure $conn exists and handle both mysqli and PDO connections.
// Collect results into $courses_data (array) so template logic doesn't call methods on booleans.
$courses_data = null;
$db_error = null;

if (!isset($conn)) {
    $db_error = 'Database connection not found. Please check config.php';
} else {
    try {
        $sql = "
            SELECT c.*, col.college_name, col.status as college_status
            FROM courses c 
            JOIN colleges col ON c.college_id = col.id 
            ORDER BY c.created_at DESC
        ";

        if ($conn instanceof mysqli) {
            $result = $conn->query($sql);
            if ($result === false) {
                $db_error = 'DB query failed';
                error_log('DB Query Error (courses.php): ' . $conn->error);
            } else {
                $courses_data = [];
                while ($row = $result->fetch_assoc()) {
                    $courses_data[] = $row;
                }
            }
        } elseif ($conn instanceof PDO) {
            $stmt = $conn->query($sql);
            if ($stmt === false) {
                $db_error = 'DB query failed (PDO)';
                // PDO error info can be logged from the PDO instance or exception
                error_log('DB Query Error (courses.php): PDO query returned false');
            } else {
                $courses_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
        } else {
            $db_error = 'Unsupported DB connection type';
            error_log('Unsupported DB connection type in courses.php');
        }
    } catch (Exception $e) {
        $db_error = 'Exception while fetching courses';
        error_log('Exception (courses.php): ' . $e->getMessage());
        $courses_data = null;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>All Courses - Admin</title>
    <link rel="stylesheet" href="../style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo">Admin Panel</div>
            <ul class="nav-links">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="colleges.php">Colleges</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="../logout.php" class="btn btn-outline-dark">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="dashboard-container">
        <h1>All Courses</h1>

        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Course Name</th>
                        <th>College</th>
                        <th>Duration</th>
                        <th>Fees</th>
                        <th>Seats Available</th>
                        <th>College Status</th>
                        <th>Added On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (is_array($courses_data) && count($courses_data) > 0): ?>
                        <?php foreach ($courses_data as $course): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($course['course_name'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($course['college_name'] ?? 'N/A'); ?></td>
                                <td><?php echo htmlspecialchars($course['duration'] ?? 'N/A'); ?></td>
                                <td>₹<?php echo number_format(floatval($course['fees'] ?? 0), 2); ?></td>
                                <td><?php echo htmlspecialchars($course['seats_available'] ?? '0'); ?></td>
                                <td>
                                    <span class="badge badge-<?php echo htmlspecialchars($course['college_status'] ?? 'unknown'); ?>">
                                        <?php echo htmlspecialchars(ucfirst($course['college_status'] ?? 'unknown')); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php 
                                        $created = $course['created_at'] ?? null;
                                        echo $created ? htmlspecialchars(date('M d, Y', strtotime($created))) : 'N/A';
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7" class="text-center">
                                <?php 
                                    if ($db_error) {
                                        echo 'Unable to fetch courses. Please check logs.';
                                    } else {
                                        echo 'No courses found';
                                    }
                                ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>