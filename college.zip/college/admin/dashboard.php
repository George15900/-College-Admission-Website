<?php 
include '../config.php';

if (!isLoggedIn() || !checkUserType('admin')) {
    redirect('../login.php');
}

// Handle college verification
if (isset($_POST['verify_college'])) {
    $college_id = $_POST['college_id'];
    $status = $_POST['status'];
    $conn->query("UPDATE colleges SET status = '$status' WHERE id = $college_id");
    $success = 'College status updated!';
}

// Get statistics
$total_colleges = $conn->query("SELECT COUNT(*) as count FROM colleges")->fetch_assoc()['count'];
$verified_colleges = $conn->query("SELECT COUNT(*) as count FROM colleges WHERE status='verified'")->fetch_assoc()['count'];
$pending_colleges = $conn->query("SELECT COUNT(*) as count FROM colleges WHERE status='pending'")->fetch_assoc()['count'];
$total_students = $conn->query("SELECT COUNT(*) as count FROM students")->fetch_assoc()['count'];
$total_courses = $conn->query("SELECT COUNT(*) as count FROM courses")->fetch_assoc()['count'];
$total_applications = $conn->query("SELECT COUNT(*) as count FROM applications")->fetch_assoc()['count'];

// Get pending colleges
$pending_colleges_list = $conn->query("SELECT c.*, u.email FROM colleges c JOIN users u ON c.user_id = u.id WHERE c.status = 'pending' ORDER BY c.created_at DESC");

// Get all colleges
$all_colleges = $conn->query("SELECT c.*, u.email FROM colleges c JOIN users u ON c.user_id = u.id ORDER BY c.created_at DESC");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo">Admin Panel</div>
            <ul class="nav-links">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="colleges.php">Colleges</a></li>
                <li><a href="courses.php">Courses</a></li>
                <li><a href="../logout.php" >Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="dashboard-container">
        <h1>Admin Dashboard</h1>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Colleges</h3>
                <p class="stat-number"><?php echo $total_colleges; ?></p>
            </div>
            <div class="stat-card">
                <h3>Verified Colleges</h3>
                <p class="stat-number"><?php echo $verified_colleges; ?></p>
            </div>
            <div class="stat-card">
                <h3>Pending Verification</h3>
                <p class="stat-number"><?php echo $pending_colleges; ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Students</h3>
                <p class="stat-number"><?php echo $total_students; ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Courses</h3>
                <p class="stat-number"><?php echo $total_courses; ?></p>
            </div>
            <div class="stat-card">
                <h3>Total Applications</h3>
                <p class="stat-number"><?php echo $total_applications; ?></p>
            </div>
        </div>

        <h2>Pending College Verifications</h2>
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>College Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Address</th>
                        <th>Registered On</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($pending_colleges_list->num_rows > 0): ?>
                        <?php while ($college = $pending_colleges_list->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $college['college_name']; ?></td>
                                <td><?php echo $college['email']; ?></td>
                                <td><?php echo $college['phone']; ?></td>
                                <td><?php echo $college['address']; ?></td>
                                <td><?php echo date('M d, Y', strtotime($college['created_at'])); ?></td>
                                <td>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="college_id" value="<?php echo $college['id']; ?>">
                                        <button type="submit" name="status" value="verified" class="btn btn-sm btn-success">Verify</button>
                                        <button type="submit" name="status" value="rejected" class="btn btn-sm btn-danger">Reject</button>
                                        <input type="hidden" name="verify_college" value="1">
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">No pending verifications</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <h2>All Colleges</h2>
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>College Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Status</th>
                        <th>Registered On</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($college = $all_colleges->fetch_assoc()): ?>
                        <tr>
                            <td><?php echo $college['college_name']; ?></td>
                            <td><?php echo $college['email']; ?></td>
                            <td><?php echo $college['phone']; ?></td>
                            <td>
                                <span class="badge badge-<?php echo $college['status']; ?>">
                                    <?php echo ucfirst($college['status']); ?>
                                </span>
                            </td>
                            <td><?php echo date('M d, Y', strtotime($college['created_at'])); ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>