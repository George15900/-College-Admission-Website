<?php 
include '../config.php';

if (!isLoggedIn() || !checkUserType('college')) {
    redirect('../login.php');
}

// Get college info
$college_info = $conn->query("SELECT c.* FROM colleges c JOIN users u ON c.user_id = u.id WHERE u.id = {$_SESSION['user_id']}")->fetch_assoc();
$college_id = $college_info['id'];

// Handle application action
if (isset($_POST['update_application'])) {
    $app_id = $_POST['app_id'];
    $status = $_POST['status'];
    $conn->query("UPDATE applications SET status = '$status', response_date = NOW() WHERE id = $app_id");
    $success = 'Application updated successfully!';
}

// Get statistics
$total_courses = $conn->query("SELECT COUNT(*) as count FROM courses WHERE college_id = $college_id")->fetch_assoc()['count'];
$pending_apps = $conn->query("SELECT COUNT(*) as count FROM applications WHERE college_id = $college_id AND status = 'pending'")->fetch_assoc()['count'];
$accepted_apps = $conn->query("SELECT COUNT(*) as count FROM applications WHERE college_id = $college_id AND status = 'accepted'")->fetch_assoc()['count'];

// Get pending applications
$applications = $conn->query("
    SELECT a.*, s.full_name, s.phone, u.email AS student_email, c.course_name
    FROM applications a
    JOIN students s ON a.student_id = s.id
    JOIN users u ON s.user_id = u.id
    JOIN courses c ON a.course_id = c.id
    WHERE a.college_id = $college_id AND a.status = 'pending'
    ORDER BY a.application_date DESC
");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>College Dashboard</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <nav class="navbar">
        <div class="container">
            <div class="logo"><?php echo $college_info['college_name']; ?></div>
            <ul class="nav-links">
                <li><a href="dashboard.php">Dashboard</a></li>
                <li><a href="courses.php">My Courses</a></li>
                <li><a href="applications.php">Applications</a></li>
                <li><a href="accepted_students.php">Accepted Students</a></li>
                <li><a href="../logout.php">Logout</a></li>
            </ul>
        </div>
    </nav>

    <div class="dashboard-container">
        <?php if ($college_info['status'] == 'pending'): ?>
            <div class="alert alert-warning">
                Your college is pending verification by admin. You will have full access once verified.
            </div>
        <?php elseif ($college_info['status'] == 'rejected'): ?>
            <div class="alert alert-error">
                Your college registration has been rejected. Please contact admin for more information.
            </div>
        <?php endif; ?>

        <h1>College Dashboard</h1>
        
        <?php if (isset($success)): ?>
            <div class="alert alert-success"><?php echo $success; ?></div>
        <?php endif; ?>

        <div class="stats-grid">
            <div class="stat-card">
                <h3>Total Courses</h3>
                <p class="stat-number"><?php echo $total_courses; ?></p>
            </div>
            <div class="stat-card">
                <h3>Pending Applications</h3>
                <p class="stat-number"><?php echo $pending_apps; ?></p>
            </div>
            <div class="stat-card">
                <h3>Accepted Students</h3>
                <p class="stat-number"><?php echo $accepted_apps; ?></p>
            </div>
            <div class="stat-card">
                <h3>Verification Status</h3>
                <p class="stat-number">
                    <span class="badge badge-<?php echo $college_info['status']; ?>">
                        <?php echo ucfirst($college_info['status']); ?>
                    </span>
                </p>
            </div>
        </div>

        <h2>Pending Student Applications</h2>
        <div class="table-container">
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Course</th>
                        <th>Applied On</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($applications->num_rows > 0): ?>
                        <?php while ($app = $applications->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo $app['full_name']; ?></td>
                                <td><?php echo $app['student_email']; ?></td>
                                <td><?php echo $app['phone']; ?></td>
                                <td><?php echo $app['course_name']; ?></td>
                                <td><?php echo date('M d, Y', strtotime($app['application_date'])); ?></td>
                                <td>
                                    <form method="POST" style="display:inline;">
                                        <input type="hidden" name="app_id" value="<?php echo $app['id']; ?>">
                                        <button type="submit" name="status" value="accepted" class="btn btn-sm btn-success">Accept</button>
                                        <button type="submit" name="status" value="rejected" class="btn btn-sm btn-danger">Reject</button>
                                        <input type="hidden" name="update_application" value="1">
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center">No pending applications</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</body>
</html>